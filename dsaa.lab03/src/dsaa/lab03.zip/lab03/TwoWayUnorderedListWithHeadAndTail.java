package dsaa.lab03;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException; //

public class TwoWayUnorderedListWithHeadAndTail<E> implements IList<E> {

	private class Element {

		public Element(E e) {
			// TODO -
			this.object = e; //
		}

		public Element(E e, Element next, Element prev) {
			// TODO
			this.object = e;
			this.next = next;
			this.prev = prev;
		}

		E object;
		Element next = null;
		Element prev = null;

	}

	Element head;
	Element tail;
	// can be realization with the field size or without
	int size;

	private class InnerIterator implements Iterator<E> {
		Element pos;
		// TODO maybe more fields....?

		public InnerIterator() {
			// TODO
			pos = head;//
		}

		@Override
		public boolean hasNext() {
			// TODO
			return pos != null;//
		}

		@Override
		public E next() {
			// TODO
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			E temp = pos.object;
			pos = pos.next;
			return temp;
		}
	}

	private class InnerListIterator implements ListIterator<E> {
		Element pos = head;
		// TODO maybe more fields....
		Element lastReturned = null;
		int index = 0;

		@Override
		public void add(E e) {
			Element newElement = new Element(e);
			if (head == null) {
				head = newElement;
				tail = newElement;
			} else if (pos == head) {
				newElement.next = head;
				head.prev = newElement;
				head = newElement;
			} else if (pos == null) {
				tail.next = newElement;
				newElement.next = tail;
				tail = newElement;
			} else {
				newElement.prev = pos.prev;
				newElement.next = pos;
				pos.prev.next = newElement;
				pos.prev = newElement;
			}
			size++;
			index++;
			lastReturned = null;
		}

		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return pos != null;
		}

		@Override
		public boolean hasPrevious() {
			// TODO Auto-generated method stub
			return pos != head;
		}

		@Override
		public E next() {
			// TODO Auto-generated method stub
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			E temp = pos.object;
			lastReturned = pos;
			pos = pos.next;
			index++;
			return temp;
		}

		@Override
		public int nextIndex() {
			return index;
		}

		@Override
		public E previous() {
			if (!hasPrevious()) {
				throw new NoSuchElementException();
			}
			if (pos == null) {
				pos = tail;
			} else {
				pos = pos.prev;
			}
			index--;
			lastReturned = pos;
			return pos.object;
		}

		@Override
		public int previousIndex() {
			return index - 1;
		}

		@Override
		public void remove() {
			if (lastReturned == null) {
				throw new IllegalStateException();
			}
			if (lastReturned == head) {
				head = head.next;
				if (head != null) {
					head.prev = null;
				}
			} else if (lastReturned == tail) {
				tail = tail.prev;
				if (tail != null) {
					tail.next = null;
				}
			} else {
				lastReturned.prev.next = lastReturned.next;
				lastReturned.next.prev = lastReturned.prev;
			}
			size--;
			index--;
			lastReturned = null;

		}

		@Override
		public void set(E e) {
			// TODO Auto-generated method stub
			if (lastReturned == null) {
				throw new IllegalStateException();
			}
			lastReturned.object = e;

		}
	}

	public TwoWayUnorderedListWithHeadAndTail() { // constructor
		// make a head and a tail
		head = null;
		tail = null;
	}

	@Override
	public boolean add(E e) { //
		// TODO
		Element newElement = new Element(e);
		if (head == null) {
			head = newElement;
			tail = newElement;
		} else {
			tail.next = newElement;
			newElement.prev = tail;
			tail = newElement;
		}
		size++;
		return true;
	}

	@Override
	public void add(int index, E element) {
	    if (index < 0 || index > size) {
	        throw new NoSuchElementException("Invalid index");
	    }
	    if (index == size) {
	        add(element);
	        return;
	    }
	    Element newElement = new Element(element);
	    if (index == 0) {
	        newElement.next = head;
	        head.prev = newElement;
	        head = newElement;
	    } else {
	        Element current = head;
	        for (int i = 0; i < index; i++) {
	            current = current.next;
	        }
	        newElement.prev = current.prev;
	        newElement.next = current;
	        current.prev.next = newElement;
	        current.prev = newElement;
	    }
	    size++;
	}


	@Override
	public void clear() {
		// TODO
		head = null;
		tail = null;
		size = 0;
	}

	@Override
	public boolean contains(E element) {
		// TODO
		Element current = head;
		while (current != null) {
			if (current.object.equals(element)) {
				return true;
			}
			current = current.next;
		}
		return false;
	}

	@Override
	public E get(int index) {
		// TODO
		if (index < 0 || index >= size) {
			throw new NoSuchElementException("Invalid index");
		}
		Element current = head;
		for (int i=0; i < index ; i++) {
			current = current.next;
		}
		return current.object;
	}

	@Override
	public E set(int index, E element) {
		if (index < 0 || index >= size) {
			throw new NoSuchElementException("Invalid index");
		}
		Element current = head;
		for (int i =0; i<index; i++) {
			current = current.next;
		}
		E oldElement = current.object;
		current.object = element;
		return oldElement;
	}

	@Override
	public int indexOf(E element) {
		// TODO
		Element current = head;
		int index = 0;
		while (current != null) {
			if (current.object.equals(element)) {
				return index;
			}
			current = current.next;
			index++;
		}
		return -1;
	}

	@Override
	public boolean isEmpty() {
		// TODO

		return size == 0;
	}

	@Override
	public Iterator<E> iterator() {
		return new InnerIterator();
	}

	@Override
	public ListIterator<E> listIterator() {
		//return new InnerListIterator();
		throw new UnsupportedOperationException();
	}

	@Override
	public E remove(int index) {
		// TODO
		if (index < 0 || index >= size) {
			throw new NoSuchElementException("Invalid index");
		}
		E removedElement;
		if (index == 0) {
			removedElement = head.object;
			head = head.next;
			if (head != null) {
				head.prev = null;
			}
		}else if (index == size -1) {
			removedElement = tail.object;
			tail = tail.prev;
			if (tail != null) {
				tail.next = null;
			}
		}else {
			Element current = head;
			for (int i = 0; i<index; i++) {
				current = current.next;
			}
			removedElement = current.object;
			current.prev.next = current.next;
			current.next.prev = current.prev;
		}
		size --;
		return removedElement;
	}

	@Override
	public boolean remove(E e) {
		// TODO
		int index = indexOf(e);
		if (index == -1) {
			return false;
		}
		remove (index);
		return true;
	}

	@Override
	public int size() {
		// TODO
		return size;
	}

	public String toStringReverse() {
	    StringBuilder retStr = new StringBuilder();
	    ListIterator<E> iter = new InnerListIterator();

	    // Move the iterator to the end of the list
	    while (iter.hasNext()) {
	        iter.next();
	    }

	    // Traverse the list backwards and append each element to the StringBuilder
	    while (iter.hasPrevious()) {
	        retStr.append(iter.previous()).append("\n");
	    }

	    return retStr.toString().trim();
	}


	public void add(TwoWayUnorderedListWithHeadAndTail<E> other) {
		if (other == this)
			return;

		if (other.head != null) {
			if (head == null) {
				head = other.head;
				tail = other.tail;
			} else {
				tail.next = other.head;
				other.head.prev = tail;
				tail = other.tail;
			}
			size += other.size;
		}

		other.clear();
	}

	
}
